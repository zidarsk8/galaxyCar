package org.psywerx.car.bluetooth;

public interface BtListener {
	public void btUnaviable();
}
